import { Camera, Check, Minus, Plus, Receipt, ScanLine, Search, ShieldCheck, Trash2, UserRound, X } from 'lucide-react'
import { Link } from 'react-router-dom'
import { Select } from '../../components/ui/Select'
import { Tooltip } from '../../components/ui/Tooltip'
import { t, intlLocale } from '../../i18n'
import { cn } from '../../lib/cn'
import { TONE_AMBER, TONE_GREEN, TONE_ROSE } from '../../lib/status'
import { formatCents } from '../../lib/money'
import { onlyDecimal } from '../../lib/numberInput'
import { getErrorMessage } from '../../services/api'
import { docPermission } from '../../auth/permissions'
import { ISSUABLE_TYPES, typeLabel } from './documentTypes'
import { isPastMonth, nowLocal, shortDate, snapIssueDate } from '../../lib/issueDate'
import { DiscountEditor } from './DiscountEditor'
import { RecargoPicker } from './RecargoPicker'
import { RecordPaymentModal } from './RecordPaymentModal'
import { QUOTE_VALID_DAYS, initials, ivaOptions, useSaleComposer } from './useSaleComposer'

const field =
  'w-full box-border rounded-lg border border-line bg-card px-3 py-1.5 text-xs text-ink outline-none focus:border-brand-600'

const label = 'mb-1 block text-[11px] font-semibold text-slate-600'

// The client card has room to breathe: taller fields, a visible focus ring, a roomier label.
const clientLabel = 'mb-1.5 block text-xs font-semibold text-slate-600'

const clientField =
  'h-10 w-full box-border rounded-xl border border-line bg-card px-3 text-[13px] text-ink outline-none transition focus:border-brand-600 focus:ring-2 focus:ring-brand-600/20'

const optionOn = 'bg-brand-50'

function InvoiceNew() {
  const {
    push,
    currency,
    company,
    editing,
    can,
    type,
    setType,
    hydrated,
    rules,
    issuedAt,
    setIssuedAt,
    datedByMonth,
    quoteEnd,
    payment,
    setPayment,
    methodOpen,
    setMethodOpen,
    setRecargoId,
    discountOpen,
    setDiscountOpen,
    discountKind,
    setDiscountKind,
    discountInput,
    setDiscountInput,
    customerId,
    clientName,
    setClientName,
    clientCompany,
    setClientCompany,
    clientPhone,
    clientNif,
    setClientNif,
    clientAddress,
    setClientAddress,
    productQuery,
    setProductQuery,
    dropdown,
    setDropdown,
    camera,
    setCamera,
    lines,
    setLines,
    printTemplates,
    companyLogo,
    existing,
    preview,
    customers,
    catalog,
    taxRates,
    recargoRates,
    selectedCustomer,
    hasClientData,
    phoneNeedle,
    phoneMatches,
    productMatches,
    lineMath,
    discountError,
    totals,
    recargo,
    recargoCents,
    grandTotal,
    noteText,
    save,
    pickCustomer,
    onPhoneChange,
    onPhoneKeyDown,
    onProductKeyDown,
    clearCustomer,
    piecesLeft,
    addProduct,
    changeLine,
    changeQuantity,
    submit,
    confirmMethod,
    issueLabel,
  } = useSaleComposer()

  if (editing && existing.isError) {
    return (
      <div className="rounded-2xl border border-rose-200 bg-rose-50 px-5 py-4 text-sm text-rose-900">
        {getErrorMessage(existing.error)}
      </div>
    )
  }

  if (editing && !hydrated) {
    return <div className="h-64 animate-pulse rounded-2xl bg-page" />
  }

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6">
      <div className="flex flex-col items-start justify-between gap-4 rounded-2xl border border-line/80 bg-card p-5 shadow-xs sm:flex-row sm:items-center">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500 text-brand-on shadow-xs">
            <Receipt className="h-5 w-5" />
          </span>
          <div>
            <h1 className="text-xl font-bold tracking-[-0.02em] text-slate-900">
              {editing
                ? type === 'albaran'
                  ? t('sales.editDeliveryNote', 'Edit delivery note')
                  : t('sales.editQuote', 'Edit quotation')
                : t('sales.newTitle', 'New sale')}
            </h1>
            <p className="mt-0.5 text-xs text-slate-500">
              {editing
                ? type === 'albaran'
                  ? t('sales.editDeliveryNoteHint', 'Change the client or the lines while it is unpaid. The number and date stay, and the stock is adjusted by the difference.')
                  : t('sales.editQuoteHint', 'Change the client or the lines. The quotation number stays.')
                : t('sales.newSubtitle', 'Invoice, delivery note, quotation or proforma, with the client and the lines on one screen.')}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span
            className={cn(
              'inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-semibold',
              rules.movesStock
                ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                : 'border-line bg-page text-slate-600',
            )}
          >
            <ShieldCheck className="h-3.5 w-3.5" />
            {rules.movesStock
              ? t('sales.stockProtected', 'Stock protected, no negatives')
              : t('sales.stockUntouched', 'Stock is not touched')}
          </span>
            <button
            type="button"
            onClick={() => {
              setDropdown(true)
              setCamera(true)
            }}
            className="inline-flex cursor-pointer items-center gap-1.5 rounded-xl border border-brand-200 bg-brand-50 px-3.5 py-1.5 text-xs font-semibold text-brand-600"
          >
            <Camera className="h-4 w-4" />
            {t('sales.camera', 'Scan code')}
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-8 rounded-3xl border border-line bg-card p-4 shadow-md sm:p-8 lg:p-10">
        <div className="grid gap-6 border-b border-slate-100 pb-6 lg:grid-cols-2">
          {rules.showsCompanyContact ? (
            <div className="flex items-center gap-4">
              {companyLogo.data ? (
                <img
                  src={companyLogo.data}
                  alt={company?.name ?? ''}
                  className="block h-auto max-h-14 w-auto max-w-[120px] shrink-0 object-contain"
                />
              ) : (
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-brand-600 text-base font-bold text-brand-on">
                  {initials(company?.name ?? t('brand.name', 'YK Digital Solutions'))}
                </span>
              )}
              <span aria-hidden="true" className="h-12 w-px shrink-0 bg-slate-200" />
              <div className="min-w-0">
                <h2 className="truncate text-lg leading-tight font-bold text-slate-900">{company?.name ?? '—'}</h2>
                {company?.email ? <p className="mt-0.5 truncate text-xs text-slate-500">{company.email}</p> : null}
                <p className="mt-0.5 truncate text-xs text-slate-400">
                  {[company?.address, company?.city].filter(Boolean).join(' · ') ||
                    t('sales.noAddress', 'No address on the company yet')}
                </p>
              </div>
            </div>
          ) : (
            <div>
              <p className="text-[11px] font-bold tracking-[0.16em] text-slate-500 uppercase">
                {t('sales.document', 'Document')}
              </p>
              <h2 className="mt-1 text-3xl font-black tracking-tight text-slate-900">{rules.title}</h2>
            </div>
          )}

          <div className="grid grid-cols-1 gap-3 rounded-2xl border border-line/80 bg-page p-4 sm:grid-cols-3">
            <div className="sm:col-span-3">
              <span className={label}>{t('sales.document', 'Document')}</span>
              {editing ? (
                <span className="block rounded-lg bg-brand-600 px-2 py-1.5 text-xs font-bold text-brand-on">
                  {typeLabel(type)}
                </span>
              ) : (
                <div className="grid grid-cols-2 gap-1.5">
                  {ISSUABLE_TYPES.filter((option) => can(docPermission(option, 'create'))).map((option) => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => setType(option)}
                      className={cn(
                        'cursor-pointer rounded-lg px-2 py-1.5 text-xs font-bold',
                        type === option ? 'bg-brand-600 text-brand-on' : 'border border-line bg-card text-ink',
                      )}
                    >
                      {typeLabel(option)}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div>
              <span className={label}>{t('sales.number', 'Number')}</span>
              <span className="block rounded-lg border border-line bg-card px-2.5 py-1.5 text-xs font-bold text-ink">
                {editing ? (existing.data?.number ?? '—') : (preview.data?.number ?? '—')}
              </span>
            </div>
            <div>
              <span className={label}>{t('sales.issuedAt', 'Date and time')}</span>
              <input
                type="datetime-local"
                value={issuedAt}
                // A quotation keeps any date; everything else is today's month up to now, or a past month's last day.
                max={datedByMonth ? nowLocal() : undefined}
                // A delivery note keeps the date its number was issued on.
                disabled={editing && type === 'albaran'}
                onChange={(event) => setIssuedAt(datedByMonth ? snapIssueDate(event.target.value) : event.target.value)}
                className="w-full rounded-lg border border-line bg-card px-2.5 py-1.5 text-xs text-ink outline-none"
              />
              {editing && type === 'albaran' ? (
                <span className="mt-1 block text-[10.5px] leading-snug text-ink-muted">
                  {t('sales.deliveryDateFixed', 'The date and number of a delivery note stay as they were issued.')}
                </span>
              ) : null}
              {!(editing && type === 'albaran') && datedByMonth && isPastMonth(issuedAt) ? (
                <span className="mt-1 block text-[10.5px] leading-snug text-ink-muted">
                  {t('sales.pastMonthHint', 'Past month: the date can only be its last day (:date).').replace(':date', shortDate(issuedAt))}
                </span>
              ) : null}
              {type === 'quotation' && quoteEnd ? (
                <span
                  className={cn(
                    'mt-1 block text-[10.5px] leading-snug',
                    quoteEnd.getTime() < Date.now() ? 'font-semibold text-rose-600' : 'text-ink-muted',
                  )}
                >
                  {quoteEnd.getTime() < Date.now()
                    ? t('sales.quoteWouldExpire', 'This date is more than a week ago, so the quotation would be expired straight away.')
                    : `${t('sales.validUntil', 'Valid until')} ${quoteEnd.toLocaleDateString(intlLocale())} (${QUOTE_VALID_DAYS} ${t('sales.daysFromDate', 'days from this date')})`}
                </span>
              ) : null}
            </div>
            {!editing && rules.settlesPayment ? (
              <div>
                <span className={label}>{t('sales.payment', 'Payment')}</span>
                <div className="grid grid-cols-2 gap-1">
                  {(['pending', 'paid'] as const).map((status) => (
                    <button
                      key={status}
                      type="button"
                      onClick={() => setPayment(status)}
                      className={cn(
                        'cursor-pointer rounded-lg px-1 py-1.5 text-[11px] font-bold',
                        payment === status
                          ? status === 'paid'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-amber-500 text-white'
                          : 'border border-line bg-card text-ink',
                      )}
                    >
                      {status === 'paid' ? t('sales.paid', 'Paid') : t('sales.pending', 'Pending')}
                    </button>
                  ))}
                </div>
              </div>
            ) : null}
          </div>
        </div>

        <div className="flex flex-col gap-4 rounded-2xl border border-brand-100 bg-page p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="flex items-center gap-2.5 text-sm font-bold tracking-[0.06em] text-slate-800 uppercase">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
                <UserRound className="h-4 w-4" />
              </span>
              {t('sales.clientHeading', 'Client')}
            </h3>
            <div className="flex items-center gap-2 text-xs">
              {customerId !== null ? (
                <span
                  className={cn(
                    'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 font-semibold',
                    TONE_GREEN,
                  )}
                >
                  <Check className="h-3 w-3" strokeWidth={3} />
                  {t('sales.savedClient', 'Saved client')}
                  {selectedCustomer ? <span className="">· {selectedCustomer.code}</span> : null}
                </span>
              ) : hasClientData ? (
                <span className="rounded-full bg-brand-100 px-2.5 py-0.5 font-semibold text-brand-600">
                  {t('sales.newClient', 'New client')}
                </span>
              ) : null}
              {hasClientData ? (
                <button
                  type="button"
                  onClick={clearCustomer}
                  className="inline-flex cursor-pointer items-center gap-1 rounded-lg px-2 py-1 font-semibold text-slate-500 transition hover:bg-rose-50 hover:text-rose-600"
                >
                  <X className="h-3.5 w-3.5" />
                  {t('sales.clearClient', 'Clear')}
                </button>
              ) : null}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-x-4 gap-y-3.5 sm:grid-cols-2">
            <div className="relative">
              <span className={clientLabel}>{t('sales.phone', 'Telephone')}</span>
              <span className="relative block">
                <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <input
                  value={clientPhone}
                  onChange={(event) => onPhoneChange(event.target.value)}
                  onKeyDown={onPhoneKeyDown}
                  inputMode="tel"
                  autoComplete="off"
                  placeholder={t('sales.phoneSearch', 'Search by phone number')}
                  className={cn(clientField, 'pl-9')}
                />
              </span>
              {customerId === null && phoneMatches.length > 0 ? (
                <div className="absolute top-full left-0 z-20 mt-1.5 w-[min(24rem,calc(100vw-2.5rem))] overflow-hidden rounded-xl border border-line bg-card shadow-lg">
                  {phoneMatches.map((customer, index) => (
                    <button
                      key={customer.id}
                      type="button"
                      onClick={() => pickCustomer(customer)}
                      className={cn(
                        'flex w-full cursor-pointer items-center gap-3 border-b border-slate-100 px-3 py-2.5 text-left last:border-0 hover:bg-slate-50',
                        index === 0 && optionOn,
                      )}
                    >
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-50 text-[11px] font-bold text-brand-600">
                        {customer.name.slice(0, 2).toUpperCase()}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-xs font-bold text-slate-900">{customer.name}</span>
                        <span className="block truncate text-[11px] text-slate-500">
                          {[customer.company_name, customer.phone, customer.nif || customer.nie].filter(Boolean).join(' · ')}
                        </span>
                      </span>
                      <span className="shrink-0 text-[10px] font-semibold text-slate-400">{customer.code}</span>
                    </button>
                  ))}
                </div>
              ) : null}
            </div>

            <div>
              <span className={clientLabel}>
                {t('sales.clientName', 'Name')}
                <span className="ml-0.5 text-rose-500">*</span>
              </span>
              <input
                value={clientName}
                onChange={(event) => setClientName(event.target.value)}
                autoComplete="off"
                className={cn(clientField, 'font-semibold')}
              />
            </div>

            <div>
              <span className={clientLabel}>{t('sales.clientCompany', 'Company name')}</span>
              <input
                value={clientCompany}
                onChange={(event) => setClientCompany(event.target.value)}
                autoComplete="off"
                className={clientField}
              />
            </div>

            <div>
              <span className={clientLabel}>{t('sales.taxId', 'N.I.F/N.I.E')}</span>
              <input
                value={clientNif}
                onChange={(event) => setClientNif(event.target.value.toUpperCase())}
                autoComplete="off"
                className={cn(clientField, 'uppercase')}
              />
            </div>

            <div className="sm:col-span-2">
              <span className={clientLabel}>{t('sales.clientAddress', 'Address')}</span>
              <input
                value={clientAddress}
                onChange={(event) => setClientAddress(event.target.value)}
                maxLength={255}
                autoComplete="off"
                placeholder={t('sales.clientAddressPlaceholder', 'Street, number, city')}
                className={clientField}
              />
            </div>
          </div>

          {customerId === null && phoneNeedle.length >= 3 ? (
            <p
              className={cn(
                'flex items-start gap-1.5 text-[11px] font-medium',
                !customers.isPending && phoneMatches.length === 0 ? 'text-brand-600' : 'text-slate-500',
              )}
            >
              <span
                aria-hidden="true"
                className={cn(
                  'mt-[5px] h-1.5 w-1.5 shrink-0 rounded-full',
                  !customers.isPending && phoneMatches.length === 0 ? 'bg-brand-500' : 'bg-slate-300',
                )}
              />
              {customers.isPending
                ? t('sales.phoneSearching', 'Searching…')
                : phoneMatches.length === 0
                  ? t('sales.phoneNew', 'No client on this number. Fill in the details — they will be saved as a new client.')
                  : t('sales.phoneEnter', 'Press Enter to use the highlighted client.')}
            </p>
          ) : null}
        </div>

        <div data-tour="pos-scan" className="relative flex flex-col gap-2">
          <span className="text-xs font-bold tracking-[0.06em] text-slate-700 uppercase">
            {t('sales.findProduct', 'Scan a barcode or search a product')}
          </span>
          <div className="flex gap-2">
            <span className="relative min-w-0 flex-1">
              <ScanLine className="absolute top-3 left-3.5 h-5 w-5 text-brand-500" />
              <input
                value={productQuery}
                onChange={(event) => {
                  setProductQuery(event.target.value)
                  setDropdown(true)
                }}
                onKeyDown={onProductKeyDown}
                onFocus={() => setDropdown(true)}
                placeholder={t('sales.productPlaceholder', 'Name or barcode')}
                className="w-full rounded-xl border-2 border-brand-500/40 bg-card py-3 pr-3 pl-11 text-sm font-medium outline-none"
              />
            </span>
          </div>
          {dropdown && !camera && productQuery.trim() !== '' ? (
            <div className="absolute top-full right-0 left-0 z-20 mt-1.5 overflow-hidden rounded-2xl border border-line bg-card shadow-xl">
              {catalog.isPending ? (
                <p className="px-4 py-3 text-xs text-slate-500">{t('sales.phoneSearching', 'Searching…')}</p>
              ) : productMatches.length === 0 ? (
                <p className="px-4 py-3 text-xs text-slate-500">{t('sales.noProduct', 'No product matches that.')}</p>
              ) : (
                productMatches.map((product, index) => (
                  <button
                    key={product.id}
                    type="button"
                    onClick={() => addProduct(product)}
                    className={cn(
                      'flex w-full cursor-pointer items-center justify-between gap-4 border-b border-slate-100 px-3.5 py-3 text-left last:border-0 hover:bg-slate-50',
                      index === 0 && optionOn,
                    )}
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-bold text-slate-900">{product.article}</span>
                      <span className="text-[11px] text-slate-500">
                        {product.barcode} · IVA {product.iva_percent}%
                      </span>
                    </span>
                    <span className="shrink-0 text-right">
                      <span className="block text-sm font-bold">{formatCents(product.selling_price, currency)}</span>
                      <span className="text-[11px] text-slate-500">
                        {piecesLeft(product.id, product.quantity)} {t('sales.left', 'left')}
                      </span>
                    </span>
                  </button>
                ))
              )}
            </div>
          ) : null}
        </div>

        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold tracking-[0.06em] text-slate-700 uppercase">
              {t('sales.lines', 'Lines')} ({lines.length})
            </span>
            {lines.length > 0 ? (
              <button type="button" onClick={() => setLines([])} className="cursor-pointer text-xs font-medium text-rose-600">
                {t('sales.clearLines', 'Clear lines')}
              </button>
            ) : null}
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-200">
            <div className="min-w-[920px]">
              <div className="flex items-center bg-slate-50 px-3 py-3 text-xs font-bold text-slate-600">
                <span className="w-10 text-center">#</span>
                <span className="min-w-0 flex-1 px-2">{t('sales.article', 'Article')}</span>
                {rules.showsAvailable ? <span className="w-40 px-2">{t('sales.available', 'Available')}</span> : null}
                <span className="w-28 shrink-0 text-center">{t('sales.qty', 'Quantity')}</span>
                {/* Each heading sits over its cell: numbers on the right edge of their box, the tax rate on the left of its list. */}
                <span className="w-28 shrink-0 px-1">
                  <span className="block pr-2 text-right">{t('sales.price', 'Price')}</span>
                </span>
                {rules.carriesDiscount ? (
                  <span className="w-20 shrink-0 px-1">
                    <span className="block pr-2 text-right">{t('sales.dto', 'Dto %')}</span>
                  </span>
                ) : null}
                {rules.carriesTax ? (
                  <span className="w-28 shrink-0 px-1">
                    <span className="block pl-2.5 text-left">{t('sales.iva', '% IVA')}</span>
                  </span>
                ) : null}
                {rules.showsPriceWithTax ? (
                  <>
                    <span className="w-28 shrink-0 px-2 text-right">{t('sales.priceNet', 'Without tax')}</span>
                    <span className="w-28 shrink-0 px-2 text-right">{t('sales.priceGross', 'With tax')}</span>
                  </>
                ) : (
                  <span className="w-28 shrink-0 px-2 text-right">{t('sales.total', 'Total')}</span>
                )}
                <span className="w-10 shrink-0" />
              </div>
              {lines.length === 0 ? (
                <p className="px-4 py-8 text-center text-xs text-slate-400">
                  {t('sales.emptyLines', 'Search a product above to add the first line.')}
                </p>
              ) : (
                lines.map((line, index) => {
                  const math = lineMath.get(line.key) ?? { base: 0, tax: 0, total: 0, iva: 0 }
                  const atStock = line.stock !== null && rules.movesStock && line.quantity >= line.stock
                  // A quotation reserves nothing, so its badge stays at the shelf count.
                  const remaining =
                    line.stock === null ? null : rules.movesStock ? line.stock - line.quantity : line.stock
                  const stockTone =
                    remaining === null
                      ? ''
                      : remaining <= 0
                        ? TONE_ROSE
                        : line.stock !== null && remaining <= Math.max(1, Math.floor(line.stock * 0.1))
                          ? TONE_AMBER
                          : TONE_GREEN
                  return (
                    <div key={line.key} className="flex items-center border-t border-slate-100 px-3 py-2.5">
                      <span className="w-10 text-center text-xs text-slate-400">{index + 1}</span>
                      <span className="min-w-0 flex-1 truncate px-2 text-xs font-bold text-slate-900">{line.article}</span>
                      {rules.showsAvailable ? (
                        <span className="flex w-40 flex-col items-start px-2">
                          {remaining === null || line.stock === null ? (
                            <span className="text-xs text-slate-400">—</span>
                          ) : (
                            <>
                              <span className={cn('rounded-full px-2 py-0.5 text-[11px] font-semibold', stockTone)}>
                                {remaining} {t('sales.left', 'left')}
                              </span>
                              <span className="mt-1 text-[10px] leading-tight text-slate-500">
                                {t('sales.ofAvailable', ':left of :stock available')
                                  .replace(':left', String(remaining))
                                  .replace(':stock', String(line.stock))}
                              </span>
                            </>
                          )}
                        </span>
                      ) : null}
                      <span className="flex w-28 shrink-0 justify-center">
                        <span className="inline-flex items-center overflow-hidden rounded-lg border border-slate-300">
                          <button type="button" onClick={() => changeQuantity(line, line.quantity - 1)} className="cursor-pointer p-1.5 text-slate-600">
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <span className="w-8 text-center text-xs font-bold">{line.quantity}</span>
                          <button
                            type="button"
                            disabled={atStock}
                            onClick={() => changeQuantity(line, line.quantity + 1)}
                            className="cursor-pointer p-1.5 text-slate-600 disabled:text-slate-300"
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </span>
                      </span>
                      <span className="w-28 shrink-0 px-1">
                        <input
                          aria-label={`${t('sales.price', 'Price')} ${line.article}`}
                          value={line.unitPrice}
                          inputMode="decimal"
                          onChange={(event) => changeLine(line.key, { unitPrice: onlyDecimal(event.target.value) })}
                          placeholder={rules.manualPrice ? t('sales.typePrice', 'Price') : undefined}
                          className={cn(
                            'w-full rounded-lg border px-2 py-1 text-right text-xs font-bold outline-none',
                            rules.manualPrice && line.unitPrice.trim() === ''
                              ? 'border-amber-400 bg-amber-50'
                              : 'border-slate-300',
                          )}
                        />
                      </span>
                      {rules.carriesDiscount ? (
                        <span className="w-20 shrink-0 px-1">
                          <input
                            aria-label={`${t('sales.dto', 'Dto %')} ${line.article}`}
                            value={line.discount}
                            inputMode="decimal"
                            onChange={(event) => changeLine(line.key, { discount: onlyDecimal(event.target.value) })}
                            className="w-full rounded-lg border border-line bg-card px-2 py-1 text-right text-xs text-ink outline-none"
                          />
                        </span>
                      ) : null}
                      {rules.carriesTax ? (
                        <span className="w-28 shrink-0 px-1">
                          <Select
                            compact
                            aria-label={t('sales.iva', '% IVA')}
                            value={line.iva}
                            onChange={(event) => changeLine(line.key, { iva: event.target.value })}
                          >
                            {ivaOptions(taxRates.data ?? [], line.iva).map((option) => (
                              <option key={option} value={option}>
                                {option}%
                              </option>
                            ))}
                          </Select>
                        </span>
                      ) : null}
                      {rules.showsPriceWithTax ? (
                        <>
                          <span className="w-28 shrink-0 px-2 text-right text-sm font-bold text-slate-900">
                            {formatCents(math.base, currency)}
                          </span>
                          <span className="w-28 shrink-0 px-2 text-right text-sm font-bold text-brand-600">
                            {formatCents(math.total, currency)}
                          </span>
                        </>
                      ) : (
                        <span className="w-28 shrink-0 px-2 text-right text-sm font-bold text-slate-900">
                          {formatCents(math.total, currency)}
                        </span>
                      )}
                      <Tooltip content={t('common.delete', 'Delete')} align="end">
                        <button
                          type="button"
                          aria-label={`${t('common.delete', 'Delete')} ${line.article}`}
                          onClick={() => setLines((current) => current.filter((item) => item.key !== line.key))}
                          className="flex w-10 shrink-0 cursor-pointer justify-center text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </Tooltip>
                    </div>
                  )
                })
              )}
            </div>
          </div>
        </div>

        <div className="grid gap-8 border-t border-slate-100 pt-4 lg:grid-cols-12">
          <div className="flex flex-col gap-3 lg:col-span-7">
            <span className="flex items-center justify-between gap-3">
              <span className="text-xs font-bold tracking-[0.06em] text-slate-700 uppercase">
                {t('sales.notes', 'Notes')}
              </span>
              <Link to="/app/printables" className="text-[11px] font-semibold text-brand-600 hover:underline">
                {t('sales.notesEdit', 'Edit in Printables')}
              </Link>
            </span>
            <div className="min-h-[76px] rounded-xl border border-line bg-page px-3 py-2.5">
              {noteText ? (
                <p className="m-0 text-xs leading-relaxed whitespace-pre-wrap text-slate-700">{noteText}</p>
              ) : (
                <p className="m-0 text-xs leading-relaxed text-slate-400">
                  {printTemplates.isPending
                    ? t('common.loading', 'Loading')
                    : t('sales.notesNone', 'No note set for this document type. Add one in Printables.')}
                </p>
              )}
            </div>
          </div>
          <div className="flex flex-col gap-4 rounded-2xl border border-line bg-page p-6 lg:col-span-5">
            <h4 className="border-b border-slate-200 pb-2 text-xs font-bold tracking-[0.06em] text-slate-900 uppercase">
              {t('sales.settlement', 'Settlement')}
            </h4>
            <div className="flex flex-col gap-2 text-xs">
              <span className="flex justify-between text-slate-600">
                <span>
                  {t('sales.subtotal', 'Subtotal')}
                </span>
                <span className="font-bold text-slate-800">
                  {formatCents(discountOpen ? totals.gross : totals.base, currency)}
                </span>
              </span>
              {rules.carriesDiscount ? (
                <DiscountEditor
                  open={discountOpen}
                  kind={discountKind}
                  value={discountInput}
                  appliedCents={discountError ? 0 : totals.discount}
                  currency={currency}
                  error={discountError}
                  onOpen={() => setDiscountOpen(true)}
                  onClear={() => {
                    setDiscountOpen(false)
                    setDiscountInput('')
                  }}
                  onKind={setDiscountKind}
                  onValue={setDiscountInput}
                />
              ) : null}
              {discountOpen && rules.carriesTax ? (
                <span className="flex justify-between text-slate-600">
                  <span>{t('sales.subtotalAfterDiscount', 'Subtotal after discount')}</span>
                  <span className="font-bold text-slate-800">{formatCents(totals.base, currency)}</span>
                </span>
              ) : null}
              {rules.carriesTax ? (
                <>
                  {totals.groups.map(([rate, group]) => (
                    <span key={rate} className="flex justify-between border-l-2 border-brand-500 pl-2 text-[11px] text-ink-muted">
                      <span>IVA {rate}% ({formatCents(group.base, currency)})</span>
                      <span className="text-slate-700">{formatCents(group.tax, currency)}</span>
                    </span>
                  ))}
                  <span className="flex justify-between text-slate-600">
                    <span>{t('sales.taxTotal', 'Tax')}</span>
                    <span className="font-bold text-slate-800">{formatCents(totals.tax, currency)}</span>
                  </span>
                  {rules.showsPriceWithTax ? (
                    <span className="flex justify-between text-slate-600">
                      <span>{t('sales.priceNet', 'Without tax')}</span>
                      <span className="font-bold text-slate-800">{formatCents(totals.base, currency)}</span>
                    </span>
                  ) : null}
                </>
              ) : null}
              {rules.allowsRecargo ? (
                <RecargoPicker
                  rates={recargoRates.data ?? []}
                  loading={recargoRates.isPending}
                  selectedId={recargo?.id ?? null}
                  onSelect={setRecargoId}
                  amountCents={recargoCents}
                  currency={currency}
                />
              ) : null}
              <span className="mt-1 flex items-baseline justify-between border-t-2 border-slate-200 pt-3">
                <span className="text-sm font-black text-slate-900">{t('sales.grandTotal', 'Total')}</span>
                <span className="text-2xl font-black text-brand-500">{formatCents(grandTotal, currency)}</span>
              </span>
            </div>
            <button
              type="button"
              disabled={save.isPending}
              onClick={submit}
              className="flex w-full cursor-pointer items-center justify-center rounded-xl bg-brand-600 px-4 py-3.5 text-sm font-bold text-brand-on shadow-md disabled:cursor-not-allowed disabled:opacity-60"
            >
              {save.isPending
                ? editing
                  ? t('common.saving', 'Saving')
                  : t('sales.issuing', 'Issuing...')
                : issueLabel}
            </button>
          </div>
        </div>
      </div>

      {camera ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-overlay p-4">
          <div role="dialog" aria-label={t('sales.camera', 'Scan code')} className="w-full max-w-md overflow-hidden rounded-2xl bg-card shadow-2xl">
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <h3 className="text-base font-semibold">{t('sales.cameraTitle', 'Find by barcode')}</h3>
              <Tooltip content={t('common.close', 'Close')} align="end" side="bottom">
                <button type="button" aria-label={t('common.close', 'Close')} onClick={() => setCamera(false)} className="cursor-pointer text-slate-400">
                  <X className="h-5 w-5" />
                </button>
              </Tooltip>
            </div>
            <form
              className="flex gap-2 p-5"
              onSubmit={(event) => {
                event.preventDefault()
                const match = productMatches.find((product) => product.barcode === productQuery.trim()) ?? productMatches[0]
                if (match) addProduct(match)
                else push({ tone: 'danger', title: t('sales.noProduct', 'No product matches that.') })
              }}
            >
              <input
                autoFocus
                value={productQuery}
                onChange={(event) => {
                  setProductQuery(event.target.value)
                  setDropdown(true)
                }}
                placeholder={t('sales.barcodePlaceholder', 'Type or scan the barcode')}
                className={cn(field, '')}
              />
              <button type="submit" className="cursor-pointer rounded-lg bg-brand-500 px-4 text-xs font-semibold text-brand-on">
                {t('sales.add', 'Add')}
              </button>
            </form>
          </div>
        </div>
      ) : null}

      <RecordPaymentModal
        open={methodOpen}
        loading={save.isPending}
        title={t('payments.issuePaidTitle', 'How was this paid?')}
        subtitle={t('payments.issuePaidSubtitle', 'The document will be issued as paid with this method.')}
        confirmLabel={issueLabel}
        onClose={() => setMethodOpen(false)}
        onConfirm={confirmMethod}
      />
    </div>
  )
}

export default InvoiceNew
