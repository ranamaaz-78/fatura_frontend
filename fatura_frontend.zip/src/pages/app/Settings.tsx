import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { AlertTriangle, Building2, Coins, CreditCard, ImagePlus, KeyRound, Mail, MessageCircle, Percent, Settings, type LucideIcon } from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useAuth } from '../../auth/AuthProvider'
import { ChangePasswordForm } from '../../components/account/ChangePasswordForm'
import { Badge } from '../../components/ui/Badge'
import { FileDropzone } from '../../components/ui/FileDropzone'
import { DocumentLanguageChoice, LanguageChoice, useChangeLanguage } from '../../components/ui/LanguageSwitcher'
import { Button } from '../../components/ui/Button'
import { Input } from '../../components/ui/Input'
import { Select } from '../../components/ui/Select'
import { Textarea } from '../../components/ui/Textarea'
import { useToast } from '../../components/ui/Toast'
import { usePermissions } from '../../auth/permissions'
import { getLocale, t, type Locale } from '../../i18n'
import { saveDocumentLocale } from '../../services/locale'
import { cn } from '../../lib/cn'
import { COMPANY_CURRENCIES, DEFAULT_CURRENCY } from '../../lib/currencies'
import { formatCurrency, formatDate, formatInterval } from '../../lib/format'
import { getAppSubscription } from '../../services/app'
import { getErrorMessage, mapValidationErrors } from '../../services/api'
import {
  createRecargoRate,
  createTaxRate,
  deleteRecargoRate,
  deleteTaxRate,
  listRecargoRates,
  listTaxRates,
  updateRecargoRate,
  updateTaxRate,
} from '../../services/catalog'
import { updateCompany } from '../../services/company'
import { loadLogoBlob, uploadCompanyLogo } from '../../services/printables'
import type { Company } from '../../types/module01'

import { RatesManager, type RatesApi } from './RatesManager'
import { WhatsAppTab } from './WhatsAppTab'
import { localCountry } from '../../lib/countries'

type TabId = 'company' | 'subscription' | 'password' | 'iva' | 'recargo' | 'whatsapp'

type CompanyDraft = {
  name: string
  email: string
  tax_id: string
  phone: string
  whatsapp: string
  address: string
  city: string
  postal_code: string
  country: string
  currency: string
}

const TABS: { id: TabId; label: string; icon: LucideIcon }[] = [
  { id: 'company', label: t('settings.tabCompany', 'Company'), icon: Building2 },
  { id: 'subscription', label: t('settings.tabSubscription', 'Subscription'), icon: CreditCard },
  { id: 'password', label: t('settings.tabPassword', 'Password'), icon: KeyRound },
  { id: 'iva', label: t('settings.tabIva', 'IVA'), icon: Percent },
  { id: 'recargo', label: t('settings.tabRecargo', 'Recargo'), icon: Coins },
  { id: 'whatsapp', label: t('settings.tabWhatsApp', 'WhatsApp'), icon: MessageCircle },
]

function parseTab(value: string | null): TabId {
  if (value === 'subscription' || value === 'password' || value === 'iva' || value === 'recargo' || value === 'whatsapp') return value
  return 'company'
}

function blankDraft(): CompanyDraft {
  return {
    name: '',
    email: '',
    tax_id: '',
    phone: '',
    whatsapp: '',
    address: '',
    city: '',
    postal_code: '',
    country: '',
    currency: DEFAULT_CURRENCY,
  }
}

function draftFrom(company: Company): CompanyDraft {
  return {
    name: company.name,
    email: company.email,
    tax_id: company.tax_id ?? '',
    phone: company.phone ?? '',
    whatsapp: company.whatsapp ?? '',
    address: company.address ?? '',
    city: company.city ?? '',
    postal_code: company.postal_code ?? '',
    country: localCountry(company.country),
    currency: company.currency,
  }
}

function CompanyTab() {
  const { session, refresh } = useAuth()
  const { push } = useToast()
  const company = session?.company ?? null
  const [draft, setDraft] = useState<CompanyDraft>(company ? draftFrom(company) : blankDraft())
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (company) setDraft(draftFrom(company))
  }, [company])

  const currencies = useMemo(() => {
    const codes = COMPANY_CURRENCIES.map((item) => item.code)
    if (draft.currency && !codes.includes(draft.currency as (typeof codes)[number])) {
      return [{ code: draft.currency, label: draft.currency }, ...COMPANY_CURRENCIES]
    }
    return COMPANY_CURRENCIES
  }, [draft.currency])

  function patch(partial: Partial<CompanyDraft>) {
    setDraft((current) => ({ ...current, ...partial }))
  }

  const save = useMutation({
    mutationFn: () =>
      updateCompany({
        name: draft.name.trim(),
        email: draft.email.trim(),
        tax_id: draft.tax_id.trim(),
        phone: draft.phone.trim(),
        whatsapp: draft.whatsapp.trim(),
        address: draft.address.trim(),
        city: draft.city.trim(),
        postal_code: draft.postal_code.trim(),
        country: draft.country.trim(),
        currency: draft.currency,
      }),
    onSuccess: async () => {
      setErrors({})
      await refresh()
      push({ tone: 'success', title: t('settings.companySaved', 'Company details saved.') })
    },
    onError: (error) => {
      setErrors(mapValidationErrors(error))
      push({ tone: 'danger', title: getErrorMessage(error) })
    },
  })

  const queryClient = useQueryClient()
  const { change: changeLanguage, pending: languagePending, canChange: canChangeLanguage } = useChangeLanguage()
  const documentLanguage = useMutation({
    mutationFn: (next: Locale | null) => saveDocumentLocale(next),
    onSuccess: async () => {
      await refresh()
      push({ tone: 'success', title: t('settings.documentLanguageSaved', 'Document language saved.') })
    },
    onError: (error) => push({ tone: 'danger', title: getErrorMessage(error) }),
  })
  const logoUrl = company?.logo_url ?? null
  const logoBlob = useQuery({
    queryKey: ['app', 'print-logo', logoUrl],
    queryFn: () => loadLogoBlob(logoUrl),
    enabled: Boolean(logoUrl),
  })

  const logoUp = useMutation({
    mutationFn: (file: File) => uploadCompanyLogo(file),
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['app', 'print-logo'] }),
        queryClient.invalidateQueries({ queryKey: ['app', 'print-templates'] }),
      ])
      await refresh()
      setErrors((current) => Object.fromEntries(Object.entries(current).filter(([key]) => key !== 'logo')))
      push({ tone: 'success', title: t('settings.logoSaved', 'Logo saved.') })
    },
    onError: (error) => push({ tone: 'danger', title: getErrorMessage(error) }),
  })

  // Everything but WhatsApp is compulsory: it prints on every invoice.
  const canSave =
    [draft.name, draft.email, draft.tax_id, draft.phone, draft.whatsapp, draft.address, draft.city, draft.postal_code, draft.country].every(
      (value) => value.trim() !== '',
    ) &&
    draft.currency.length === 3

  return (
    <div className="flex flex-col gap-5 p-5">
      <p className="text-xs text-slate-500">
        {t(
          'settings.companyHint',
          'These details print on your invoices, quotes and proformas, so every one of them is compulsory.',
        )}
      </p>

      <div className="rounded-2xl border border-line bg-page/60 p-4">
        <p className="text-sm font-semibold text-slate-900">{t('settings.language', 'Language')}</p>
        <p className="mt-0.5 mb-3 text-xs text-slate-500">
          {canChangeLanguage
            ? t('settings.languageHint', 'The language of your whole company: the app, invoices, quotations, emails and WhatsApp messages.')
            : t('settings.languageStaff', 'Your company owner chooses the language for everyone.')}
        </p>
        <LanguageChoice
          tone="app"
          value={getLocale()}
          disabled={!canChangeLanguage}
          busy={languagePending ? getLocale() : null}
          onChange={(next) => void changeLanguage(next)}
        />
      </div>

      <div className="rounded-2xl border border-line bg-page/60 p-4">
        <p className="text-sm font-semibold text-slate-900">{t('settings.documentLanguage', 'Document language')}</p>
        <p className="mt-0.5 mb-3 text-xs text-slate-500">
          {t(
            'settings.documentLanguageHint',
            'The language printed on invoices, quotations, proformas and delivery notes. It can differ from the language of the app.',
          )}
        </p>
        <DocumentLanguageChoice
          value={company?.document_locale ?? null}
          disabled={!canChangeLanguage || documentLanguage.isPending}
          onChange={(next) => documentLanguage.mutate(next)}
        />
      </div>

      <div
        className={cn(
          'rounded-2xl border p-4',
          errors.logo ? 'border-rose-300 bg-rose-50/40' : 'border-line bg-page/60',
        )}
      >
        <p className="text-sm font-semibold text-slate-900">
          {t('settings.companyLogo', 'Company logo')} <span className="font-normal text-slate-400">{t('publicField.optional', '(optional)')}</span>
        </p>
        <p className="mt-0.5 text-xs text-slate-500">
          {t('settings.logoHint', 'Shown at the top of your documents. A square or wide logo on a plain or transparent background looks best.')}
        </p>
        <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-center">
          <span className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-line bg-white">
            {logoBlob.data ? (
              <img src={logoBlob.data} alt="" className="h-full w-full object-contain p-1" />
            ) : (
              <ImagePlus className="h-6 w-6 text-slate-300" />
            )}
          </span>
          <div className="min-w-0 flex-1">
            <FileDropzone accept="image/jpeg,image/png,image/webp" disabled={logoUp.isPending} onFile={(file) => logoUp.mutate(file)}>
              <p className="text-xs font-semibold text-slate-700">
                {logoUrl
                  ? t('settings.replaceLogo', 'Drop a new logo or click to replace it')
                  : t('settings.dropLogo', 'Drop your logo or click to upload')}
              </p>
              <p className="mt-1 text-[11px] text-slate-400">{t('settings.logoTypes', 'JPEG, PNG or WebP · 5 MB max')}</p>
            </FileDropzone>
          </div>
        </div>
        {errors.logo ? <p className="mt-2 text-xs font-medium text-rose-600">{errors.logo}</p> : null}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Input
          label={t('settings.companyName', 'Company name')}
          value={draft.name}
          error={errors.name}
          required
          onChange={(event) => patch({ name: event.target.value })}
        />
        <Input
          type="email"
          label={t('settings.email', 'Email')}
          value={draft.email}
          error={errors.email}
          required
          onChange={(event) => patch({ email: event.target.value })}
        />
        <Input
          label={t('settings.taxId', 'NIF / NIE / CIF')}
          hint={t('settings.taxIdHint', 'Your tax number, printed on every invoice.')}
          value={draft.tax_id}
          error={errors.tax_id}
          required
          autoCapitalize="characters"
          onChange={(event) => patch({ tax_id: event.target.value })}
        />
        <Input
          label={t('settings.phone', 'Phone')}
          value={draft.phone}
          error={errors.phone}
          required
          onChange={(event) => patch({ phone: event.target.value })}
        />
        <Input
          label={t('settings.whatsapp', 'WhatsApp')}
          value={draft.whatsapp}
          error={errors.whatsapp}
          required
          onChange={(event) => patch({ whatsapp: event.target.value })}
        />
        <div className="sm:col-span-2">
          <Textarea
            label={t('settings.address', 'Address')}
            rows={3}
            value={draft.address}
            error={errors.address}
            required
            onChange={(event) => patch({ address: event.target.value })}
          />
        </div>
        <Input
          label={t('settings.city', 'City')}
          value={draft.city}
          error={errors.city}
          required
          onChange={(event) => patch({ city: event.target.value })}
        />
        <Input
          label={t('settings.postalCode', 'Postal code')}
          value={draft.postal_code}
          error={errors.postal_code}
          required
          autoCapitalize="characters"
          onChange={(event) => patch({ postal_code: event.target.value })}
        />
        <Input
          label={t('settings.country', 'Country')}
          value={draft.country}
          error={errors.country}
          required
          onChange={(event) => patch({ country: event.target.value })}
        />
        <Select
          label={t('settings.currency', 'Currency')}
          hint={t(
            'settings.currencyHint',
            'Used when amounts are shown. Existing documents keep the numbers they already have.',
          )}
          value={draft.currency}
          error={errors.currency}
          required
          onChange={(event) => patch({ currency: event.target.value })}
        >
          {currencies.map((item) => (
            <option key={item.code} value={item.code}>
              {item.code} — {item.label}
            </option>
          ))}
        </Select>
      </div>
      <p className="text-[11px] text-slate-400">
        {t('settings.properCase', 'Names, address and city are saved with capital letters, for example "Taller de Marta S.L.".')}
      </p>
      <div>
        <Button type="button" disabled={!canSave} loading={save.isPending} onClick={() => save.mutate()}>
          {t('common.save', 'Save')}
        </Button>
      </div>
    </div>
  )
}

function PasswordTab() {
  return (
    <div className="p-5">
      <ChangePasswordForm scope="app" />
    </div>
  )
}

const IVA_API: RatesApi = {
  list: listTaxRates,
  create: createTaxRate,
  update: updateTaxRate,
  remove: deleteTaxRate,
}

const RECARGO_API: RatesApi = {
  list: listRecargoRates,
  create: createRecargoRate,
  update: updateRecargoRate,
  remove: deleteRecargoRate,
}

function IvaTab() {
  return (
    <RatesManager
      queryKey={['app', 'tax-rates']}
      api={IVA_API}
      hint={t('settings.ivaHint', 'These IVA rates appear on products and on the invoice.')}
      namePlaceholder={t('settings.rateNamePlaceholder', 'General')}
      ratePlaceholder="21"
      added={t('settings.rateAdded', 'IVA rate added.')}
      updated={t('settings.rateUpdated', 'IVA rate updated.')}
      removed={t('settings.rateRemoved', 'IVA rate removed.')}
      deleteTitle={t('settings.deleteRateTitle', 'Remove this IVA rate?')}
      deleteBody={t(
        'settings.deleteRateBody',
        ':name will disappear from the product and invoice lists. Products that already use it keep their rate.',
      )}
    />
  )
}

function RecargoTab() {
  return (
    <RatesManager
      queryKey={['app', 'recargo-rates']}
      api={RECARGO_API}
      hint={t(
        'settings.recargoHint',
        'Recargo de equivalencia is the surcharge some retailers pay on top of IVA. Keep the rates you use here.',
      )}
      namePlaceholder={t('settings.recargoNamePlaceholder', 'General')}
      ratePlaceholder="5.2"
      added={t('settings.recargoAdded', 'Recargo rate added.')}
      updated={t('settings.recargoUpdated', 'Recargo rate updated.')}
      removed={t('settings.recargoRemoved', 'Recargo rate removed.')}
      deleteTitle={t('settings.deleteRecargoTitle', 'Remove this recargo rate?')}
      deleteBody={t('settings.deleteRecargoBody', ':name will be removed from your recargo list.')}
      emptyText={t('settings.noRecargo', 'No recargo rates yet. Add the ones your business uses.')}
    />
  )
}

function SubscriptionTab() {
  const query = useQuery({ queryKey: ['app', 'subscription'], queryFn: getAppSubscription })

  if (query.isPending) {
    return (
      <div className="space-y-3 p-5">
        <span className="block h-5 w-40 animate-pulse rounded-xl bg-slate-100" />
        <span className="block h-4 w-full animate-pulse rounded-xl bg-slate-100" />
        <span className="block h-4 w-2/3 animate-pulse rounded-xl bg-slate-100" />
      </div>
    )
  }

  const subscription = query.data?.subscription ?? null
  const support = query.data?.support
  const expired = !subscription || !subscription.is_usable
  const waDigits = support?.whatsapp?.replace(/\D+/g, '') ?? ''

  if (expired) {
    return (
      <div className="flex flex-col items-start gap-5 p-5 sm:flex-row">
        <span className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-amber-50 text-amber-600 app-dark:bg-amber-500/15 app-dark:text-amber-300">
          <AlertTriangle className="h-6 w-6" />
        </span>
        <div className="flex-1">
          <h2 className="text-lg font-bold text-slate-900">
            {t('expired.title', 'Your subscription has ended')}
          </h2>
          <p className="mt-1.5 max-w-xl text-sm leading-relaxed text-slate-600">
            {t('expired.body', 'Your workspace is safe and your data is untouched. Renew to pick up where you left off.')}
          </p>
          {subscription ? (
            <p className="mt-3 text-xs text-slate-500">
              {t('expired.endedOn', 'Ended on')} {formatDate(subscription.ends_at)}
            </p>
          ) : null}
          <p className="mt-6 text-[11px] font-semibold tracking-wider text-slate-500 uppercase">
            {t('expired.contact', 'Contact us to renew')}
          </p>
          <div className="mt-2 flex flex-col gap-2 sm:flex-row">
            {waDigits ? (
              <a
                href={`https://wa.me/${waDigits}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-xl border border-line bg-card px-4 py-3 text-sm font-semibold text-ink hover:bg-page"
              >
                <MessageCircle className="h-4 w-4 text-emerald-600" />
                {support?.whatsapp}
              </a>
            ) : null}
            {support?.email ? (
              <a
                href={`mailto:${support.email}`}
                className="inline-flex items-center gap-2 rounded-xl border border-line bg-card px-4 py-3 text-sm font-semibold text-ink hover:bg-page"
              >
                <Mail className="h-4 w-4 text-brand-600" />
                {support.email}
              </a>
            ) : null}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-slate-900">{subscription.plan_name}</h2>
          <p className="mt-1 text-sm text-slate-600">
            {formatCurrency(subscription.plan_price, subscription.plan_currency)} /{' '}
            {formatInterval(subscription.plan_interval)}
          </p>
        </div>
        <Badge status={subscription.status.toUpperCase()} />
      </div>
      <p className="mt-3 text-sm text-slate-700">
        {t('admin.renewsOn', 'Renews on')} {formatDate(subscription.ends_at)} · {subscription.days_left}{' '}
        {t('admin.daysLeft', 'days left')}
      </p>
      {subscription.plan_features.length > 0 ? (
        <ul className="mt-5 grid gap-1.5 sm:grid-cols-2">
          {subscription.plan_features.map((feature, index) => (
            <li key={`${index}-${feature}`} className="text-sm text-slate-600">
              · {feature}
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  )
}

function Page() {
  const { can, isOwner } = usePermissions()
  const [params, setParams] = useSearchParams()
  const [tab, setTab] = useState<TabId>(() => parseTab(params.get('tab')))

  useEffect(() => {
    setTab(parseTab(params.get('tab')))
  }, [params])

  // The subscription is the owner's; the company, rates and WhatsApp wording need Settings; a password is everyone's own.
  const tabs = TABS.filter((item) => {
    if (item.id === 'subscription') return isOwner
    if (item.id === 'password') return true
    return can('settings.view')
  })
  const canEdit = can('settings.update')
  // The page opens on the company tab; someone who may not see it lands on the first tab they can.
  const activeTab: TabId = tabs.some((item) => item.id === tab) ? tab : (tabs[0]?.id ?? 'password')
  const readOnly = activeTab !== 'password' && activeTab !== 'subscription' && !canEdit

  function selectTab(id: string) {
    const next = parseTab(id)
    setTab(next)
    setParams(next === 'company' ? {} : { tab: next }, { replace: true })
  }

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-4">
      <div className="flex items-center gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-brand-50 text-brand-600">
          <Settings className="h-5 w-5" />
        </span>
        <div>
          <h1 className="text-xl font-bold tracking-[-0.02em] text-ink">{t('nav.settings', 'Settings')}</h1>
          <p className="mt-0.5 text-xs text-ink-muted">
            {t('settings.subtitle', 'Company details, subscription, password and IVA rates.')}
          </p>
        </div>
      </div>

      <div className="overflow-hidden rounded-2xl border border-line/80 bg-card shadow-xs sm:flex">
        <nav
          aria-label={t('nav.settings', 'Settings')}
          className="grid grid-cols-2 gap-1 border-b border-line bg-page/80 p-2 sm:flex sm:w-56 sm:shrink-0 sm:flex-col sm:border-r sm:border-b-0 sm:p-3"
        >
          {tabs.map((item) => {
            const Icon = item.icon
            const active = activeTab === item.id
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => selectTab(item.id)}
                className={cn(
                  'inline-flex w-full min-w-0 items-center justify-center gap-2 rounded-xl px-3 py-3 text-xs font-semibold sm:justify-start sm:py-2.5',
                  'focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:ring-offset-1',
                  active
                    ? 'bg-card text-brand-600 shadow-xs ring-1 ring-line/80 sm:bg-brand-50 sm:shadow-none sm:ring-0'
                    : 'text-ink-muted hover:bg-card/80 hover:text-ink sm:hover:bg-page',
                )}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            )
          })}
        </nav>
        <div className="min-w-0 flex-1">
          {readOnly ? (
            <p className="m-5 mb-0 rounded-xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-900">
              {t('settings.readOnly', 'You can look at these settings, but only the owner can change them.')}
            </p>
          ) : null}
          {/* A disabled fieldset switches off every field and button inside it. */}
          <fieldset
            disabled={readOnly}
            className={cn('contents', readOnly && 'read-only-actions')}
          >
            {activeTab === 'company' && tabs.some((item) => item.id === 'company') ? <CompanyTab /> : null}
            {activeTab === 'subscription' && isOwner ? <SubscriptionTab /> : null}
            {activeTab === 'password' ? <PasswordTab /> : null}
            {activeTab === 'iva' && tabs.some((item) => item.id === 'iva') ? <IvaTab /> : null}
            {activeTab === 'recargo' && tabs.some((item) => item.id === 'recargo') ? <RecargoTab /> : null}
            {activeTab === 'whatsapp' && tabs.some((item) => item.id === 'whatsapp') ? <WhatsAppTab /> : null}
          </fieldset>
        </div>
      </div>
    </div>
  )
}

export default Page
